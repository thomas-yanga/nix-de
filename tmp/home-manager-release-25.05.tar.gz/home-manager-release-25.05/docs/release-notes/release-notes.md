# Release Notes {#ch-release-notes}

This section lists the release notes for stable versions of Home Manager
and the current unstable version.

```{=include=} chapters
rl-2505.md
rl-2411.md
rl-2405.md
rl-2311.md
rl-2305.md
rl-2211.md
rl-2205.md
rl-2111.md
rl-2105.md
rl-2009.md
rl-2003.md
rl-1909.md
rl-1903.md
rl-1809.md
```
