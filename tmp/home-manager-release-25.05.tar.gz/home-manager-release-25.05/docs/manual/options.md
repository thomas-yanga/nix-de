# Home Manager Configuration Options {#ch-options}

```{=include=} options
id-prefix: opt-
list-id: home-manager-options
source: @OPTIONS_JSON@
```
