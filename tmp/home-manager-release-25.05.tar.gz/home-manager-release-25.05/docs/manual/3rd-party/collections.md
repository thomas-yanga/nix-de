# Module Collections {#sec-3rd-party-module-collections}

-   [xhmm --- extra Home Manager
    modules](https://github.com/schuelermine/xhmm)

    A collection of modules maintained by Anselm Schüler.

-   [Stylix --- System-wide colorscheming and
    typography](https://github.com/danth/stylix/)

    Configure your applications to get coherent color scheme and font.
