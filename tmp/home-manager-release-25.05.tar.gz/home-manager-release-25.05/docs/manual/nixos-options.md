# NixOS Configuration Options {#ch-nixos-options}

```{=include=} options
id-prefix: nixos-opt-
list-id: nixos-options
source: @OPTIONS_JSON@
```
