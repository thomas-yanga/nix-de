# nix-darwin Configuration Options {#ch-nix-darwin-options}

```{=include=} options
id-prefix: nix-darwin-opt-
list-id: nix-darwin-options
source: @OPTIONS_JSON@
```
