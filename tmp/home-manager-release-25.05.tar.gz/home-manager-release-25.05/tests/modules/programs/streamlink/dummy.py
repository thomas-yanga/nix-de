"""
$description Dummy plugin for testing
"""

from streamlink.plugin import Plugin

class DummyTV(Plugin):

__plugin__ = DummyTV
