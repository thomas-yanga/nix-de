#!/bin/sh
echo "pre-commit hook..."
