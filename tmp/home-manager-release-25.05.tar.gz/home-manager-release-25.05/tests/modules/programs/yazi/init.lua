require("zoxide"):setup {
  update_db = true,
}
